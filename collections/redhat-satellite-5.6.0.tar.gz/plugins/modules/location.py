#!/usr/bin/python
# -*- coding: utf-8 -*-
# (c) 2017, Matthias M Dellweg <dellweg@atix.de> (ATIX AG)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import absolute_import, division, print_function
__metaclass__ = type


DOCUMENTATION = '''
---
module: location
version_added: 1.0.0
short_description: Manage Locations
description:
  - Manage Locations
author:
  - "Matthias M Dellweg (@mdellweg) ATIX AG"
options:
  name:
    description:
      - Name of the Location
    required: true
    type: str
  description:
    description:
      - Description of the Location
    required: false
    type: str
    version_added: 4.2.0
  parent:
    description:
      - Title of a parent Location for nesting
    type: str
  organizations:
    description:
      - List of organizations the location should be assigned to
    type: list
    elements: str
  ignore_types:
    description:
      - List of resources types that will be automatically associated
    type: list
    elements: str
    required: false
    aliases:
      - select_all_types
    version_added: 3.8.0
extends_documentation_fragment:
  - redhat.satellite.foreman
  - redhat.satellite.foreman.entity_state
  - redhat.satellite.foreman.nested_parameters
'''

EXAMPLES = '''
# Create a simple location
- name: "Create CI Location"
  redhat.satellite.location:
    username: "admin"
    password: "changeme"
    server_url: "https://satellite.example.com"
    name: "My Cool New Location"
    organizations:
      - "Default Organization"
    state: present

# Create a nested location
- name: "Create Nested CI Location"
  redhat.satellite.location:
    username: "admin"
    password: "changeme"
    server_url: "https://satellite.example.com"
    name: "My Nested location"
    parent: "My Cool New Location"
    state: present

# Create a new nested location with parent included in name
- name: "Create New Nested Location"
  redhat.satellite.location:
    username: "admin"
    password: "changeme"
    server_url: "https://satellite.example.com"
    name: "My Cool New Location/New nested location"
    state: present

# Move a nested location to another parent
- name: "Create Nested CI Location"
  redhat.satellite.location:
    username: "admin"
    password: "changeme"
    server_url: "https://satellite.example.com"
    name: "My Cool New Location/New nested location"
    parent: "My Cool New Location/My Nested location"
    state: present
'''

RETURN = '''
entity:
  description: Final state of the affected entities grouped by their type.
  returned: success
  type: dict
  contains:
    locations:
      description: List of locations.
      type: list
      elements: dict
'''

from ansible_collections.redhat.satellite.plugins.module_utils.foreman_helper import ForemanEntityAnsibleModule, NestedParametersMixin


class ForemanLocationModule(NestedParametersMixin, ForemanEntityAnsibleModule):
    pass


def main():
    module = ForemanLocationModule(
        foreman_spec=dict(
            name=dict(required=True),
            description=dict(required=False),
            parent=dict(type='entity'),
            organizations=dict(type='entity_list'),
            ignore_types=dict(type='list', elements='str', required=False, aliases=['select_all_types']),
            select_all_types=dict(type='list', invisible=True, flat_name='ignore_types'),
        ),
    )

    with module.api_connection():
        entity = module.lookup_entity('entity')

        # workround the fact that the API expects `ignore_types` when modifying the entity
        # but uses `select_all_types` when showing one
        if entity and 'select_all_types' in entity:
            entity['ignore_types'] = entity.pop('select_all_types')

        module.run()


if __name__ == '__main__':
    main()
